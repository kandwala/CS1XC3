var searchData=
[
  ['student_2ec_0',['student.c',['../student_8c.html',1,'']]],
  ['student_2eh_1',['student.h',['../student_8h.html',1,'']]]
];
