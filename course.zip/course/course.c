/**
 * @file course.c
 * @author Aaryan Kandwal (you@domain.com)
 * @brief Course Functions File
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 


/**
 * @brief a function that helps enroll a student in a course by taking their course type 
 * and student type and then adding them to the students array
 * 
 * @param course: The course the students are added to
 * @param student: The student to be added to the course
 */
void enroll_student(Course *course, Student *student)
{
  /* the total number of students in the course is increased. The calloc is used to create an array
  with the memory for 1 item if it is the first student in the course. If this is not the case then
   then dynamic memory reaccolation is implemented to add more students into the course
   */

  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief a function that prints out the information of students in each course in the array, such as names, course code
 * and total students
 * 
 * @param course The course the students are added to
 */
void print_course(Course* course)
{

  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief takes a course as input, and returns the student with the highest average in the course
 * 
 * @param course the course the students are added to
 * @return Student* The top student who has the highest average
 */
Student* top_student(Course* course)
{
  /* If there are no students in the course, NULL is returned. 
  It this isnt the case it goes through thecourse to store the student with the highest
  average and then returns their average
   */
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief A function that takes course and the number of student in it as input and returns an array of
 * all the student passing as well as increasing the amount of total students passing
 * 
 * @param course the course students are added to
 * @param total_passing the amount of students who are passing
 * @return Student* 
 */

Student *passing(Course* course, int *total_passing)
{
  /* Goes through the students in the course and increases count if the student is passing. After cycling 
  through an array is created with memory size amount of the amount of students who are passing and all
  the students who are passing are stored into it. This array is then returned.
  */
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}